package com.ctf.quizchallenge

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ScoreActivity : AppCompatActivity() {
    
    private lateinit var scoreText: TextView
    private lateinit var accuracyText: TextView
    private lateinit var questionsText: TextView
    private lateinit var flagsText: TextView
    private lateinit var newHighScoreText: TextView
    private lateinit var playAgainButton: Button
    private lateinit var mainMenuButton: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score)
        
        initializeViews()
        setupClickListeners()
        displayResults()
    }
    
    private fun initializeViews() {
        scoreText = findViewById(R.id.scoreText)
        accuracyText = findViewById(R.id.accuracyText)
        questionsText = findViewById(R.id.questionsText)
        flagsText = findViewById(R.id.flagsText)
        newHighScoreText = findViewById(R.id.newHighScoreText)
        playAgainButton = findViewById(R.id.playAgainButton)
        mainMenuButton = findViewById(R.id.mainMenuButton)
    }
    
    private fun setupClickListeners() {
        playAgainButton.setOnClickListener {
            val intent = Intent(this, QuizActivity::class.java)
            startActivity(intent)
            finish()
        }
        
        mainMenuButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
    
    private fun displayResults() {
        val score = intent.getIntExtra("score", 0)
        val totalQuestions = intent.getIntExtra("total_questions", 0)
        val correctAnswers = intent.getIntExtra("correct_answers", 0)
        val isNewHighScore = intent.getBooleanExtra("is_new_high_score", false)
        
        val accuracy = if (totalQuestions > 0) {
            (correctAnswers * 100) / totalQuestions
        } else {
            0
        }
        
        val flagManager = FlagManager(this)
        val flagsCollected = flagManager.getFlagCount()
        val totalFlags = flagManager.getTotalFlagCount()
        
        scoreText.text = "Final Score: $score"
        accuracyText.text = "Accuracy: $accuracy%"
        questionsText.text = "Correct: $correctAnswers / $totalQuestions"
        flagsText.text = "Flags Collected: $flagsCollected / $totalFlags"
        
        if (isNewHighScore) {
            newHighScoreText.text = "🎉 NEW HIGH SCORE! 🎉"
            newHighScoreText.visibility = android.view.View.VISIBLE
        } else {
            newHighScoreText.visibility = android.view.View.GONE
        }
        
        // Show performance message
        val performanceMessage = when {
            accuracy >= 90 -> "Excellent! You're a CTF master!"
            accuracy >= 80 -> "Great job! You're getting there!"
            accuracy >= 70 -> "Good work! Keep practicing!"
            accuracy >= 60 -> "Not bad! Study more and try again!"
            else -> "Keep learning! Practice makes perfect!"
        }
        
        // You could add a TextView to display this message
    }
}
