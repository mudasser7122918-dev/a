package com.ctf.quizchallenge

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AnalyticsActivity : AppCompatActivity() {
    
    private lateinit var flagCountText: TextView
    private lateinit var flagRecyclerView: RecyclerView
    private lateinit var backButton: Button
    private lateinit var databaseHelper: DatabaseHelper
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analytics)
        
        initializeViews()
        setupClickListeners()
        loadFlags()
    }
    
    private fun initializeViews() {
        flagCountText = findViewById(R.id.flagCountText)
        flagRecyclerView = findViewById(R.id.flagRecyclerView)
        backButton = findViewById(R.id.backButton)
        
        databaseHelper = DatabaseHelper(this)
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }
    }
    
    private fun loadFlags() {
        val flagsCollected = databaseHelper.getFlagCount()
        val totalFlags = databaseHelper.getTotalFlagCount()
        
        flagCountText.text = "Flags Collected: $flagsCollected / $totalFlags"
        
        // Get all questions with flags
        val questionsWithFlags = QuizData.generateAllQuestions().filter { it.flag != null }
        val collectedFlags = databaseHelper.getCollectedFlags()
        
        val flagItems = questionsWithFlags.map { question ->
            val flagId = "${question.category}_${question.flag!!.hashCode()}"
            val isCollected = collectedFlags.contains(flagId)
            
            FlagItem(
                flag = question.flag!!,
                category = question.category,
                description = "Question ${question.id}: ${question.question}",
                isCollected = isCollected
            )
        }
        
        val adapter = DataAdapter(flagItems)
        flagRecyclerView.layoutManager = LinearLayoutManager(this)
        flagRecyclerView.adapter = adapter
    }
}

data class FlagItem(
    val flag: String,
    val category: String,
    val description: String,
    val isCollected: Boolean
)

