package com.ctf.quizchallenge

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class DatabaseHelper(private val context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences("flag_manager", Context.MODE_PRIVATE)
    private val gson = Gson()
    
    fun collectFlag(flag: String, category: String) {
        val collectedFlags = getCollectedFlags()
        val flagId = "${category}_${flag.hashCode()}"
        
        if (!collectedFlags.contains(flagId)) {
            collectedFlags.add(flagId)
            saveCollectedFlags(collectedFlags)
        }
    }
    
    fun isFlagCollected(flag: String, category: String): Boolean {
        val collectedFlags = getCollectedFlags()
        val flagId = "${category}_${flag.hashCode()}"
        return collectedFlags.contains(flagId)
    }
    
    fun getCollectedFlags(): MutableSet<String> {
        val flagsJson = prefs.getString("collected_flags", "[]")
        val type = object : TypeToken<MutableSet<String>>() {}.type
        return gson.fromJson(flagsJson, type) ?: mutableSetOf()
    }
    
    private fun saveCollectedFlags(flags: MutableSet<String>) {
        val flagsJson = gson.toJson(flags)
        prefs.edit().putString("collected_flags", flagsJson).apply()
    }
    
    fun getFlagCount(): Int {
        return getCollectedFlags().size
    }
    
    fun getTotalFlagCount(): Int {
        return QuizData.generateAllQuestions().count { it.flag != null }
    }
    
    fun resetFlags() {
        prefs.edit().remove("collected_flags").apply()
    }
    
    fun getFlagsByCategory(): Map<String, Int> {
        val collectedFlags = getCollectedFlags()
        val categoryCount = mutableMapOf<String, Int>()
        
        QuizData.generateAllQuestions().forEach { question ->
            if (question.flag != null && collectedFlags.contains("${question.category}_${question.flag.hashCode()}")) {
                categoryCount[question.category] = (categoryCount[question.category] ?: 0) + 1
            }
        }
        
        return categoryCount
    }
    
    // Hidden flag - only accessible through reverse engineering
    private fun getHiddenFlag(): String {
        val secret = "ICSSC{Hidden_Flag_Deep_In_The_Code_Reverse_Me}"
        val encoded = secret.toByteArray().map { it.toInt() }.joinToString(",")
        return encoded
    }
    
    fun revealHiddenFlag(): String {
        val encoded = getHiddenFlag()
        val decoded = encoded.split(",").map { it.toInt().toByte() }.toByteArray()
        return String(decoded)
    }
}
