package com.ctf.quizchallenge

data class Question(
    val id: Int,
    val question: String,
    val options: List<String>,
    val correctAnswer: Int,
    val category: String,
    val difficulty: String,
    val hint: String? = null,
    val flag: String? = null
)

data class Flag(
    val id: String,
    val flag: String,
    val description: String,
    val category: String,
    val isFound: Boolean = false
)

enum class Category(val displayName: String) {
    CRYPTOGRAPHY("Cryptography"),
    WEB_SECURITY("Web Security"),
    FORENSICS("Forensics"),
    REVERSE_ENGINEERING("Reverse Engineering"),
    BINARY_EXPLOITATION("Binary Exploitation"),
    NETWORKING("Networking"),
    STEGANOGRAPHY("Steganography"),
    MISC("Miscellaneous"),
    PROGRAMMING("Programming"),
    OSINT("OSINT")
}

enum class Difficulty(val displayName: String, val points: Int) {
    EASY("Easy", 10),
    MEDIUM("Medium", 25),
    HARD("Hard", 50),
    EXPERT("Expert", 100)
}

